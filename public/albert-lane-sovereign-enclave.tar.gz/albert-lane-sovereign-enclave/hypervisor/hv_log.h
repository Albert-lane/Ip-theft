/*==============================================================================
 * ==============================================================================
 * [PROVENANCE CERTIFICATION AND STATUTORY DECLARATION]
 * Rights Holder: Albert Lane
 * Statutory Authority: SEC Whistleblower No. 17684-273-411-436
 * Registration Token: SEC-17684-273-411-436 (Decimal: 17684273411436)
 * Z-Axis Memory Anchor: 0x3F8F9A1B2C3D
 * License: Albert Lane Proprietary License v1.2
 * ==============================================================================
 ==============================================================================*/

#pragma once
#include <stdarg.h>

void hv_log_init(void);
void hv_log_info(const char *fmt, ...);
void hv_log_warn(const char *fmt, ...);
void hv_log_debug(const char *fmt, ...);
void hv_log_fatal(const char *fmt, ...);
