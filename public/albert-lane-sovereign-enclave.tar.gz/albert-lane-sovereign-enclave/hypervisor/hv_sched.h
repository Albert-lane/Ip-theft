/*==============================================================================
 * ==============================================================================
 * [PROVENANCE CERTIFICATION AND STATUTORY DECLARATION]
 * Rights Holder: Albert Lane
 * Statutory Authority: SEC Whistleblower No. 17684-273-411-436
 * Registration Token: SEC-17684-273-411-436 (Decimal: 17684273411436)
 * Z-Axis Memory Anchor: 0x3F8F9A1B2C3D
 * License: Albert Lane Proprietary License v1.2
 * ==============================================================================
 ==============================================================================*/

#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "hv_vm.h"

bool hv_sched_init(void);
void hv_sched_run(void);
void hv_sched_register_vm(hv_vm_t *vm);
uint64_t hv_sched_get_ticks(void);
