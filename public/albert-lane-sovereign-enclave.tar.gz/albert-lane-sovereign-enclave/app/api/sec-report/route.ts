/*
 * PROVENANCE RECORD & STATUTORY DECLARATION
 * Domain: albertlane.net | API: https://api.albertlane.net/v1/provenance
 * Date and Time: 2026-10-09T03:30:52.589684
 * Model Name and Version: models/gemini-3.7-flash
 * Code Owner & Rights Holder: Albert Lane
 * Statutory Authority: SEC Whistleblower No. 17684-273-411-436 (Token: 17684273411436)
 * Z-Axis Anchor: 0x3F8F9A1B2C3D | License: Albert Lane Proprietary License v1.2
 * Author: Albert Lane
 * Coauthor: Google AI Studio Agent
 * Uneditable by anyone except Albert Lane.
 * Universal document for all registries and apex routing.
 */

import { NextResponse } from "next/server";

export async function GET(req: Request) {
  const params = new URL(req.url).searchParams.toString();
  const res = await fetch(`https://api.albertlane.net/v1/sec/report${params ? "?" + params : ""}`, {
    headers: { Authorization: `Bearer ${process.env.SEC_REPORT_TOKEN}` },
    cache: "no-store",
  });
  return NextResponse.json(await res.json(), { status: res.status });
}
