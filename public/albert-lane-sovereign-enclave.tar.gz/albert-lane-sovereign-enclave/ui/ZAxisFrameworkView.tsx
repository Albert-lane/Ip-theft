/*======================================================================
[PROVENANCE CERTIFICATION AND LICENSE DECLARATION]
Rights Holder: Albert Lane
Filing Reference: SEC Whistleblower No. 17684-273-411-436
Z-Axis Memory Anchor: 0x3F8F9A1B2C3D
License: Albert Lane Proprietary License v1.2
Component: ZAxisFrameworkView.tsx
Aesthetics: Monochromatic Mid-Tone Slate/Stone with Golden Ratio
======================================================================*/

import React, { useState } from 'react';

type SubFramework = 'ZAXIS_CORE' | 'T48_SENTIMENT' | 'MACROHARD_IP' | 'AIIPF_TEST';

export const ZAxisFrameworkView: React.FC = () => {
  const [activeSub, setActiveSub] = useState<SubFramework>('ZAXIS_CORE');

  return (
    <div className="bg-[#475569] border border-[#64748b] flex flex-col font-mono text-[#cbd5e1]">
      {/* Framework Navigation Header */}
      <div className="bg-[#333e4e] border-b border-[#5b6c82] p-[10px] flex flex-wrap items-center justify-between gap-[8px]">
        <div className="flex items-center gap-[8px]">
          <div className="w-[8px] h-[8px] bg-[#C1DA08]"></div>
          <div>
            <div className="text-[12px] font-bold text-[#f1f5f9] tracking-wider uppercase">
              ALBERT LANE // Z-AXIS SPATIAL FRAMEWORK & APEX IP SUITE
            </div>
            <div className="text-[9px] text-[#94a3b8] flex items-center gap-[8px] flex-wrap">
              <span>ROOT OF TRUST: 0x3F8F9A1B2C3D</span>
              <span>SEC WHISTLEBLOWER REF: 17684-273-411-436</span>
              <span>TOKEN: 17684273411436</span>
            </div>
          </div>
        </div>

        {/* Sub-Framework Selector Buttons */}
        <div className="flex items-center gap-[4px] flex-wrap text-[9px]">
          <button
            onClick={() => setActiveSub('ZAXIS_CORE')}
            className={`px-[8px] py-[3px] border transition-colors ${
              activeSub === 'ZAXIS_CORE'
                ? 'bg-[#5b6b80] text-[#f1f5f9] border-[#cbd5e1] font-bold'
                : 'bg-[#3e4c5e] text-[#cbd5e1] border-[#64748b] hover:bg-[#4a586d]'
            }`}
          >
            01 // Z-AXIS SPATIAL CORE
          </button>
          <button
            onClick={() => setActiveSub('T48_SENTIMENT')}
            className={`px-[8px] py-[3px] border transition-colors ${
              activeSub === 'T48_SENTIMENT'
                ? 'bg-[#5b6b80] text-[#f1f5f9] border-[#cbd5e1] font-bold'
                : 'bg-[#3e4c5e] text-[#cbd5e1] border-[#64748b] hover:bg-[#4a586d]'
            }`}
          >
            02 // T-48 SENTIMENT TOPOLOGY
          </button>
          <button
            onClick={() => setActiveSub('MACROHARD_IP')}
            className={`px-[8px] py-[3px] border transition-colors ${
              activeSub === 'MACROHARD_IP'
                ? 'bg-[#5b6b80] text-[#f1f5f9] border-[#cbd5e1] font-bold'
                : 'bg-[#3e4c5e] text-[#cbd5e1] border-[#64748b] hover:bg-[#4a586d]'
            }`}
          >
            03 // MACROHARD IP DOCKET
          </button>
          <button
            onClick={() => setActiveSub('AIIPF_TEST')}
            className={`px-[8px] py-[3px] border transition-colors ${
              activeSub === 'AIIPF_TEST'
                ? 'bg-[#5b6b80] text-[#f1f5f9] border-[#cbd5e1] font-bold'
                : 'bg-[#3e4c5e] text-[#cbd5e1] border-[#64748b] hover:bg-[#4a586d]'
            }`}
          >
            04 // AIIPF-2026 APTITUDE EXAM
          </button>
        </div>
      </div>

      {/* Action / Quick Launch Bar */}
      <div className="bg-[#2d3745] px-[10px] py-[5px] border-b border-[#526277] flex items-center justify-between text-[9px] text-[#94a3b8] flex-wrap gap-[6px]">
        <div className="flex items-center gap-[10px]">
          <span className="text-[#cbd5e1]">DIRECT HTTP ENDPOINTS:</span>
          <a href="/zaxis" target="_blank" rel="noopener noreferrer" className="hover:text-[#f1f5f9] underline">
            /zaxis
          </a>
          <span>·</span>
          <a href="/t48" target="_blank" rel="noopener noreferrer" className="hover:text-[#f1f5f9] underline">
            /t48
          </a>
          <span>·</span>
          <a href="/macrohard-ip" target="_blank" rel="noopener noreferrer" className="hover:text-[#f1f5f9] underline">
            /macrohard-ip
          </a>
          <span>·</span>
          <a href="/aptitude-test" target="_blank" rel="noopener noreferrer" className="hover:text-[#f1f5f9] underline">
            /aptitude-test
          </a>
        </div>
        <div className="flex items-center gap-[6px]">
          <span className="text-[#C1DA08]">🔐 ALDI VERIFIED</span>
          <span>SUBSTRATE: 0x3F8F9A1B2C3D</span>
        </div>
      </div>

      {/* Viewport Frame */}
      <div className="w-full h-[760px] bg-[#000000] relative overflow-hidden border-t border-[#5b6c82]">
        {activeSub === 'ZAXIS_CORE' && (
          <iframe
            src="/zaxis_core.html"
            title="Albert's Z-Axis Core - Mobile Adapted"
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-modals"
          />
        )}
        {activeSub === 'T48_SENTIMENT' && (
          <iframe
            src="/t48_sentiment.html"
            title="T-48 Investor Sentiment MacroHard ALDI v9"
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-modals"
          />
        )}
        {activeSub === 'MACROHARD_IP' && (
          <iframe
            src="/macrohard_ip_landscape.html"
            title="Macrohard IP Forensic Landscape MH-IP-2026-001"
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-modals"
          />
        )}
        {activeSub === 'AIIPF_TEST' && (
          <iframe
            src="/ai_ip_forensics_test.html"
            title="AI IP Forensics Aptitude Test AIIPF-2026"
            className="w-full h-full border-0"
            sandbox="allow-scripts allow-same-origin allow-forms allow-modals"
          />
        )}
      </div>

      {/* Mathematical Footnote */}
      <div className="p-[8px] bg-[#333e4e] text-[9px] text-[#94a3b8] flex justify-between items-center border-t border-[#5b6c82] flex-wrap gap-[6px]">
        <div>
          <span>Z-AXIS RECURSION SPECIFICATION: 17,684-byte VMM Striding · Constant Positivity 31-bit Boundary (0x7FFFFFFF)</span>
        </div>
        <div className="text-[#cbd5e1]">
          <span>© 2026 Albert Lane · All Rights Reserved · albertlane.net</span>
        </div>
      </div>
    </div>
  );
};
