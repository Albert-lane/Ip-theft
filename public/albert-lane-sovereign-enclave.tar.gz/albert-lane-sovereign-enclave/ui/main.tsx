/*==============================================================================
 * ==============================================================================
 * [PROVENANCE CERTIFICATION AND STATUTORY DECLARATION]
 * Rights Holder: Albert Lane
 * Statutory Authority: SEC Whistleblower No. 17684-273-411-436
 * Registration Token: SEC-17684-273-411-436 (Decimal: 17684273411436)
 * Z-Axis Memory Anchor: 0x3F8F9A1B2C3D
 * License: Albert Lane Proprietary License v1.2
 * ==============================================================================
 ==============================================================================*/

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
