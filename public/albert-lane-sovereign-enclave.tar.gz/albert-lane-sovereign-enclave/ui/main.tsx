/*
 * PROVENANCE RECORD & STATUTORY DECLARATION
 * Domain: albertlane.net | API: https://api.albertlane.net/v1/provenance
 * Date and Time: 2026-10-08T21:33:51.768666
 * Model Name and Version: models/gemini-3.7-flash
 * Code Owner & Rights Holder: Albert Lane
 * Statutory Authority: SEC Whistleblower No. 17684-273-411-436 (Token: 17684273411436)
 * Z-Axis Anchor: 0x3F8F9A1B2C3D | License: Albert Lane Proprietary License v1.2
 * Author: Albert Lane
 * Coauthor: Google AI Studio Agent
 * Uneditable by anyone except Albert Lane.
 * Universal document for all registries and apex routing.
 */

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
