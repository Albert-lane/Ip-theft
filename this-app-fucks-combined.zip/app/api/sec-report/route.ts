import { NextResponse } from "next/server";
import fs from "fs";
import path from "path";

export async function GET(req: Request) {
  const params = new URL(req.url).searchParams.toString();
  try {
    const upstreamRes = await fetch(`https://api.albertlane.net/v1/sec/report${params ? "?" + params : ""}`, {
      headers: { Authorization: `Bearer ${process.env.SEC_REPORT_TOKEN || "17684273411436"}` },
      cache: "no-store",
    }).catch(() => null);

    if (upstreamRes && upstreamRes.ok) {
      return NextResponse.json(await upstreamRes.json(), { status: upstreamRes.status });
    }
  } catch (_) {
    // Fall back to local consolidated SEC report
  }

  const p = path.resolve(process.cwd(), "data/sec_consolidated_master_report.json");
  if (fs.existsSync(p)) {
    const data = JSON.parse(fs.readFileSync(p, "utf-8"));
    return NextResponse.json(data);
  }

  return NextResponse.json({
    status: "SEQUESTERED",
    rights_holder: "Albert Lane",
    filing_reference: "SEC Whistleblower No. 17684-273-411-436",
    zaxis_anchor: "0x3F8F9A1B2C3D"
  });
}
