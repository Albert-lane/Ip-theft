/*==============================================================================
 * [PROVENANCE CERTIFICATION AND STATUTORY DECLARATION]
 * Rights Holder: Albert Lane
 * Statutory Authority: SEC Whistleblower No. 17684-273-411-436
 * Z-Axis Memory Anchor: 0x3F8F9A1B2C3D
 * Component: App.tsx (Main Sovereign Navigation & Monorepo Interface)
 * Aesthetics: Strict Monochromatic Slate/Stone Palette (Zero Pill / Golden Ratio)
 *==============================================================================*/

import React, { useState } from 'react';
import { CursorScanView } from './components/CursorScanView';
import { ViolationsLogView } from './components/ViolationsLogView';
import { ZAxisFrameworkView } from './components/ZAxisFrameworkView';
import { SecRegistryView } from './components/SecRegistryView';
import { SovereignPackagingView } from './components/SovereignPackagingView';
import { MarketplaceMcpView } from './components/MarketplaceMcpView';
import { WebsiteCaptureView } from './components/WebsiteCaptureView';

type TabType = 'CURSOR_SCAN' | 'VIOLATIONS_LOG' | 'MARKETPLACE_MCP' | 'WEBSITE_CAPTURE' | 'ZAXIS' | 'SEC_REGISTRY' | 'PACKAGING';

export const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('CURSOR_SCAN');

  return (
    <div className="min-h-screen bg-[#334155] text-[#cbd5e1] font-mono flex flex-col p-[13px] md:p-[21px] max-w-[1440px] mx-auto">
      {/* Top Provenance & Statutory Header */}
      <header className="bg-[#1e293b] border border-[#475569] p-[13px] mb-[13px] flex flex-wrap items-center justify-between gap-[13px]">
        <div>
          <div className="text-[14px] font-bold text-[#f8fafc] tracking-widest uppercase">
            ALBERT LANE // SOVEREIGN ENCLAVE & CORPUS AST SCANNER
          </div>
          <div className="text-[10px] text-[#94a3b8] flex flex-wrap gap-[13px] mt-[3px]">
            <span>RIGHTS HOLDER: ALBERT LANE</span>
            <span>APEX DOMAIN: albertlane.net</span>
            <span>SEC WHISTLEBLOWER REF: 17684-273-411-436</span>
            <span>Z-AXIS ANCHOR: 0x3F8F9A1B2C3D</span>
          </div>
        </div>

        <div className="flex items-center gap-[8px] text-[10px]">
          <span className="w-[6px] h-[6px] bg-[#34d399] inline-block"></span>
          <span className="text-[#f8fafc] font-bold">SUBSTRATE ONLINE</span>
          <span className="text-[#64748b]">v1.2.4</span>
        </div>
      </header>

      {/* Primary Navigation Tabs */}
      <nav className="flex flex-wrap gap-[5px] mb-[13px] text-[10px] border-b border-[#475569] pb-[8px]">
        <button
          onClick={() => setActiveTab('CURSOR_SCAN')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'CURSOR_SCAN'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          01 // CURSOR DATABASE SCAN POOL
        </button>

        <button
          onClick={() => setActiveTab('VIOLATIONS_LOG')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'VIOLATIONS_LOG'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          02 // GLOBAL LICENSE VIOLATIONS LOG
        </button>

        <button
          onClick={() => setActiveTab('MARKETPLACE_MCP')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'MARKETPLACE_MCP'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          03 // MARKETPLACE & MCP ECOSYSTEM
        </button>

        <button
          onClick={() => setActiveTab('WEBSITE_CAPTURE')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'WEBSITE_CAPTURE'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          04 // LIVE WEBSITE & DNS INGRESS
        </button>

        <button
          onClick={() => setActiveTab('ZAXIS')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'ZAXIS'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          05 // Z-AXIS SPATIAL CORE
        </button>

        <button
          onClick={() => setActiveTab('SEC_REGISTRY')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'SEC_REGISTRY'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          06 // SEC WHISTLEBLOWER REGISTRY
        </button>

        <button
          onClick={() => setActiveTab('PACKAGING')}
          className={`px-[13px] py-[6px] border uppercase transition-colors cursor-pointer ${
            activeTab === 'PACKAGING'
              ? 'bg-[#1e293b] text-[#f8fafc] border-[#cbd5e1] font-bold'
              : 'bg-[#334155] text-[#94a3b8] border-[#475569] hover:text-[#f8fafc]'
          }`}
        >
          07 // SOVEREIGN PACKAGING & API
        </button>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1">
        {activeTab === 'CURSOR_SCAN' && <CursorScanView />}
        {activeTab === 'VIOLATIONS_LOG' && <ViolationsLogView />}
        {activeTab === 'MARKETPLACE_MCP' && <MarketplaceMcpView />}
        {activeTab === 'WEBSITE_CAPTURE' && <WebsiteCaptureView />}
        {activeTab === 'ZAXIS' && <ZAxisFrameworkView />}
        {activeTab === 'SEC_REGISTRY' && <SecRegistryView />}
        {activeTab === 'PACKAGING' && <SovereignPackagingView />}
      </main>

      {/* Footer */}
      <footer className="mt-[21px] pt-[13px] border-t border-[#475569] flex flex-wrap justify-between items-center text-[9px] text-[#94a3b8]">
        <div>
          <span>STATUTORY DECLARATION: SEC-17684-273-411-436 · TOKEN: 17684273411436</span>
        </div>
        <div>
          <span>© 2026 ALBERT LANE · SOVEREIGN ARCHITECT · albertlane.net</span>
        </div>
      </footer>
    </div>
  );
};
