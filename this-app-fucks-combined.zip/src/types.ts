/*==============================================================================
 * [PROVENANCE CERTIFICATION AND STATUTORY DECLARATION]
 * Rights Holder: Albert Lane
 * Filing Reference: SEC Whistleblower No. 17684-273-411-436
 * Z-Axis Memory Anchor: 0x3F8F9A1B2C3D
 * License: Albert Lane Proprietary License v1.2
 *==============================================================================*/

export interface LicenseViolation {
  id: number;
  infringing_entity: string;
  infringing_product: string;
  infringement_category: string;
  misappropriated_asset: string;
  statutory_basis: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  timestamp: string;
  evidence_details?: string;
  structural_evidence_keys?: string;
  remedy_demanded?: string;
}

export interface ScanPool {
  id: number;
  corpus_name: string;
  entity_owner: string;
  corpus_type: string;
  status: string;
  schemas_indexed: number;
  last_scanned: string;
}

export interface CursorStatus {
  status: string;
  schemas_count: number;
  violations_count: number;
  sample_schemas: Array<[string, string, number, string]>;
  provenance?: {
    rightsHolder: string;
    filingReference: string;
    zaxisMemoryAnchor: string;
  };
}

export interface CursorCodebaseFinding {
  id: number;
  file_path: string;
  line_number: number;
  symbol_or_function: string;
  infringement_type: string;
  misappropriated_asset: string;
  statutory_basis: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM';
  code_snippet: string;
  evidence_analysis: string;
  remedy_demanded: string;
  evidence_sha256?: string;
  timestamp: string;
}

